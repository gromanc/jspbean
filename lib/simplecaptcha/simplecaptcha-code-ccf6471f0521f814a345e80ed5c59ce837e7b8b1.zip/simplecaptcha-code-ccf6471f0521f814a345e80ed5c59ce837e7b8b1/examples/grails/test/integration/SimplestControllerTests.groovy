class SimplestControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
